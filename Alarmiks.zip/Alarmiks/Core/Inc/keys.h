#ifndef __KEYS_H__
#define __KEYS_H__

#include "main.h"
#include "tim.h"
#include "gpio.h"
#include "button.h"

extern uint8_t But0_State, But1_State;
extern Button_Handle_t *hbut1, *hbut0;

// Button identifiers
#define BUTTON_B0   0
#define BUTTON_B1   1
#define NUM_BUTTONS 2

// Button event types
#define BUTTON_EVENT_NONE        0
#define BUTTON_EVENT_SHORT_PRESS 1
#define BUTTON_EVENT_LONG_PRESS  2

// Initialize the keys module with the call frequency in Hertz (Hz)
void Keys_Init(uint16_t call_frequency_hz);

// Set the long press threshold (milliseconds) if different from default
void Keys_SetLongPressThreshold(uint16_t threshold_ms);

// Function to process button states, to be called in periodic interrupt
void Keys_Process(void);

// Function to get the button event
uint8_t Keys_GetEvent(uint8_t button);

// Function to clear the button event after processing
void Keys_ClearEvent(uint8_t button);

#endif // __KEYS_H__