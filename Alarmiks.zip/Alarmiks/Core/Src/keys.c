// 
#include "keys.h"

uint8_t But0_State, But1_State;
uint16_t call_freq;


// Default constants
#define DEFAULT_LONG_PRESS_THRESHOLD_MS   2000  // Default long press threshold in milliseconds
#define DEFAULT_CALL_FREQUENCY_HZ         100   // Default call frequency in Hertz

typedef enum {
    BUTTON_STATE_IDLE,
    BUTTON_STATE_PRESS_DETECTED,
    BUTTON_STATE_PRESSED,
    BUTTON_STATE_LONG_PRESSED
} ButtonInternalState_t;

typedef struct {
    uint8_t currentState;
    uint8_t previousState;
    uint32_t pressDurationMs;       // Duration in milliseconds
    uint8_t event;                  // BUTTON_EVENT_NONE, BUTTON_EVENT_SHORT_PRESS, BUTTON_EVENT_LONG_PRESS
    ButtonInternalState_t internalState; // Internal state machine
    uint8_t eventGenerated;         // Flag to indicate event has been generated (1 or 0)
} ButtonStatus_t;

static ButtonStatus_t buttons[NUM_BUTTONS];
static uint16_t callFrequencyHz = DEFAULT_CALL_FREQUENCY_HZ;
static uint16_t processIntervalMs = 0; // Calculated from call frequency
static uint16_t longPressThresholdMs = DEFAULT_LONG_PRESS_THRESHOLD_MS;

void Keys_Init(uint16_t call_frequency_hz)
{
    // Prevent division by zero
    if (call_frequency_hz == 0) {
        call_frequency_hz = DEFAULT_CALL_FREQUENCY_HZ;
    }
    callFrequencyHz = call_frequency_hz;
    processIntervalMs = 1000 / callFrequencyHz; // Convert frequency to interval in milliseconds

    // Ensure the interval is at least 1 ms
    if (processIntervalMs == 0) {
        processIntervalMs = 1;
    }

    for (uint8_t i = 0; i < NUM_BUTTONS; i++)
    {
        buttons[i].currentState = 0;
        buttons[i].previousState = 0;
        buttons[i].pressDurationMs = 0;
        buttons[i].event = BUTTON_EVENT_NONE;
        buttons[i].internalState = BUTTON_STATE_IDLE;
        buttons[i].eventGenerated = 0;
    }
}

void Keys_SetLongPressThreshold(uint16_t threshold_ms)
{
    longPressThresholdMs = threshold_ms;
}

void Keys_Process(void)
{
    // Read the debounced button states
    uint8_t buttonStates[NUM_BUTTONS];
    buttonStates[BUTTON_B0] = But0_State;
    buttonStates[BUTTON_B1] = But1_State;

    for (uint8_t i = 0; i < NUM_BUTTONS; i++)
    {
        buttons[i].previousState = buttons[i].currentState;
        buttons[i].currentState = buttonStates[i];

        switch (buttons[i].internalState)
        {
            case BUTTON_STATE_IDLE:
                if (buttons[i].currentState)
                {
                    // Button press detected
                    buttons[i].pressDurationMs = 0;
                    buttons[i].eventGenerated = 0;
                    buttons[i].internalState = BUTTON_STATE_PRESS_DETECTED;
                }
                break;

            case BUTTON_STATE_PRESS_DETECTED:
                if (buttons[i].currentState)
                {
                    // Button is still pressed
                    buttons[i].pressDurationMs += processIntervalMs;
                    if (buttons[i].pressDurationMs >= longPressThresholdMs)
                    {
                        if (!buttons[i].eventGenerated)
                        {
                            // Long press detected
                            buttons[i].event = BUTTON_EVENT_LONG_PRESS;
                            buttons[i].eventGenerated = 1;
                            buttons[i].internalState = BUTTON_STATE_LONG_PRESSED;
                        }
                    }
                    else
                    {
                        buttons[i].internalState = BUTTON_STATE_PRESSED;
                    }
                }
                else
                {
                    // False trigger, return to idle
                    buttons[i].internalState = BUTTON_STATE_IDLE;
                }
                break;

            case BUTTON_STATE_PRESSED:
                if (buttons[i].currentState)
                {
                    // Button is still pressed
                    buttons[i].pressDurationMs += processIntervalMs;
                    if (buttons[i].pressDurationMs >= longPressThresholdMs)
                    {
                        if (!buttons[i].eventGenerated)
                        {
                            // Long press detected
                            buttons[i].event = BUTTON_EVENT_LONG_PRESS;
                            buttons[i].eventGenerated = 1;
                            buttons[i].internalState = BUTTON_STATE_LONG_PRESSED;
                        }
                    }
                }
                else
                {
                    // Button released before long press threshold
                    if (!buttons[i].eventGenerated)
                    {
                        buttons[i].event = BUTTON_EVENT_SHORT_PRESS;
                        buttons[i].eventGenerated = 1;
                    }
                    buttons[i].internalState = BUTTON_STATE_IDLE;
                }
                break;

            case BUTTON_STATE_LONG_PRESSED:
                if (!buttons[i].currentState)
                {
                    // Button released after long press
                    buttons[i].internalState = BUTTON_STATE_IDLE;
                }
                // Do nothing while button remains pressed after long press event
                break;

            default:
                buttons[i].internalState = BUTTON_STATE_IDLE;
                break;
        }
    }
}

uint8_t Keys_GetEvent(uint8_t button)
{
    if (button < NUM_BUTTONS)
    {
        return buttons[button].event;
    }
    else
    {
        return BUTTON_EVENT_NONE;
    }
}

void Keys_ClearEvent(uint8_t button)
{
    if (button < NUM_BUTTONS)
    {
        buttons[button].event = BUTTON_EVENT_NONE;
    }
}


Button_Handle_t* hbut1, *hbut0;